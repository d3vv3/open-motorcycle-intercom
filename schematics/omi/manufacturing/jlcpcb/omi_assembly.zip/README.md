# OMI JLCPCB Release Notes

## Board

- Size: 100 mm x 50 mm rounded rectangle
- Finished thickness: 1.6 mm
- Layers: 4
- Finish: ENIG
- Stackup: JLCPCB `JLC04161H-7628`
- Layer order: F.Cu / In1.Cu GND / In2.Cu 3.3 V / B.Cu
- Copper: 35 / 17.5 / 17.5 / 35 um
- Dielectrics: 0.2104 mm 7628 / 1.065 mm FR-4 / 0.2104 mm 7628

The stackup is embedded in `omi.kicad_pcb`. Order the named JLCPCB stackup and
request impedance review for the 0.35 mm F.Cu RF geometry over In1.Cu. The
IPC-2141 estimate is approximately 50.0 ohms.

## Verification

- `omi_erc.rpt`: 0 violations
- `omi_drc.rpt`: 0 violations and 0 unconnected items
- Four copper Gerbers and the Gerber job file identify a 1.6 mm ENIG,
  impedance-controlled board.
- PTH and NPTH Excellon drills are separate and use millimeters.

## Assembly

- `omi_bom.csv`: JLCPCB part numbers are in the `LCSC` column.
- `omi_cpl.csv`: KiCad CSV placement data in millimeters.
- DNP: C40, C41, R21, C80. Their footprints remain for tuning or fallback use.
- C29 is the only bottom-side populated component.
- Verify the JLCPCB placement preview for side, rotation, origin, and negative
  KiCad Y coordinates before submitting the order.

## Mandatory Holds

- Submit the 0.10 mm nRF ball escapes, local 3 mil spacing, 0.15 mm SMD pad
  spacing, and regulator neck-downs to JLCPCB DFM review.
- The preserved USB D+/D- routing is not a continuous controlled 90 ohm pair.
  Validate USB signal integrity on assembled hardware.
- Tune the antenna matching network on assembled hardware.
- Limit RF output to both 20 dBm and the regional EIRP limit. Conducted power
  must satisfy `Pout <= EIRP_limit - antenna_gain + feed_loss`; positive antenna
  gain therefore reduces the allowed conducted setting.
- Validate power thermal behavior, audio noise, connector openings, component
  height, and enclosure fit before volume manufacture.

## Files

- `omi_gerber_drill.zip`: board fabrication upload
- `omi_assembly.zip`: BOM and placement upload
- `gerbers/`: source Gerbers and job file
- `drill/`: Excellon drills and PDF maps
